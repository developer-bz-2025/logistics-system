<?php $__env->startSection('title', __('Unauthorized')); ?>
<?php $__env->startSection('code', '401'); ?>
<?php $__env->startSection('message', __('Unauthorized')); ?>

<?php echo $__env->make('errors::minimal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\logistic\backend\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions/views/401.blade.php ENDPATH**/ ?>