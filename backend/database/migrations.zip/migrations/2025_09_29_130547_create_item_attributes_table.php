<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('item_attributes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('item_id')->constrained('items')->cascadeOnDelete();
            $table->foreignId('att_id')->constrained('attributes')->cascadeOnDelete();
            // optional: store chosen option or free text
            $table->foreignId('att_option_id')->nullable()->constrained('att_options')->nullOnDelete();
            $table->string('value')->nullable();
            $table->timestamps();

            $table->unique(['item_id','att_id']); // one value per attribute per item
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('item_attributes');
    }
};
