<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class FixedItem extends Model
{
    use HasFactory;

    protected $fillable = ['name','sub_id'];

    public function subCategory()
    {
        return $this->belongsTo(SubCategory::class, 'sub_id');
    }

    public function attributes()
    {
        return $this->hasMany(ItemAttribute::class);
    }

    public function items()
    {
        return $this->hasMany(Item::class, 'fixed_item_id');
    }

    public function attributeOptions()
    {
        return $this->belongsToMany(AttOption::class, 'item_att_options', 'fixed_item_id', 'att_option_id')
                    ->withTimestamps();
    }
}
