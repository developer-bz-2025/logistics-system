<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ItemAttOption extends Model
{
    use HasFactory;

    protected $table = 'item_att_options';
    protected $fillable = ['fixed_item_id','att_option_id'];
    public function fixedItem()      { return $this->belongsTo(FixedItem::class, 'fixed_item_id'); }
    public function attOption() { return $this->belongsTo(AttOption::class, 'att_option_id'); }
}
