<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ItemAttribute extends Model
{
    use HasFactory;

    protected $table = 'item_attributes';
    protected $fillable = ['item_id','att_id'];

    public function fixedItem()      { return $this->belongsTo(FixedItem::class, 'item_id'); }
    public function attribute() { return $this->belongsTo(Attribute::class, 'att_id'); }
}
