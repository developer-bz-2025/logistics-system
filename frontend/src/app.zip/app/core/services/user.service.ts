import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private apiUrl = `${environment.apiBaseUrl}/users`;


    constructor(private http:HttpClient) { }

  createUser(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}`, data);
  }

  updateUser(data:any):Observable<any>{
    return this.http.put(`${this.apiUrl}/${data.id}`,data);
  }

  deleteUser(userId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${userId}`);
  }

  getUsers(): Observable<any> {
    return this.http.get(`${this.apiUrl}`);
  }

  getAssignedUsers(): Observable<any> {
    return this.http.get(`${this.apiUrl}/assigned-users`);
  }

  getUser(id:number){
    return this.http.get(`${this.apiUrl}/${id}`);
  }

}
