import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EntityService {

 
  private apiUrl = `${environment.apiBaseUrl}`;

  constructor(private http:HttpClient) { }

  createEntity(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/entities`, data);
  }

  getEntities(){
    return this.http.get(`${this.apiUrl}/entities`);
  }

  entityDetails(id:number){
    return this.http.get(`${this.apiUrl}/entities/${id}`);
  }
}
