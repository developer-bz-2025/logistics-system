import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class JwtService {

  constructor() { }

  
  getToken(): string | null {
    return localStorage.getItem('access_token'); // adjust if stored under different key
  }

  decodeToken(): any {
    const token = this.getToken();
    if (!token) return null;

    const payload = token.split('.')[1];
    const decodedPayload = atob(payload);
    
    return JSON.parse(decodedPayload);
  }

  getUserId(): number | null {
    const decoded = this.decodeToken();
    return decoded?.sub || null;
  }
}
