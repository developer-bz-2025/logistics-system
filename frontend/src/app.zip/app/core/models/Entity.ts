export interface Entity {
    entity_id : number;
    entity_name: string;
    entity_description: string;
  }
  