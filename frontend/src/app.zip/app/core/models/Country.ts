export interface Country {
    country_id : number;
    country_name: string;
    country_description: string;
  }