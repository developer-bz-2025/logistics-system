import { Component, ViewEncapsulation, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  encapsulation: ViewEncapsulation.None,
})
export class AppDashboardComponent {


  displayedColumns: string[] = ['name', 'entities', 'docs'];
  dataSource: any;

  constructor(private router : Router) {
  }

  navigateTo(path: string) {
    this.router.navigateByUrl(path);
  }

  dashboardCards = [
    { label: 'Users', value: 127, icon: '👤', bgColor: 'bg-blue-50', textColor: 'text-blue-600' },
    { label: 'Resources', value: 342, icon: '📦', bgColor: 'bg-yellow-50', textColor: 'text-yellow-600' },
    { label: 'Units', value: 12, icon: '🏢', bgColor: 'bg-cyan-50', textColor: 'text-cyan-600' },
    { label: 'Entities', value: 4, icon: '🏛️', bgColor: 'bg-red-50', textColor: 'text-red-600' },
    { label: 'Countries', value: 3, icon: '🌍', bgColor: 'bg-green-50', textColor: 'text-green-600' },
    { label: 'Projects', value: 45, icon: '📁', bgColor: 'bg-indigo-50', textColor: 'text-indigo-600' },
    // { label: 'Staff Roles', value: 20, icon: '🧑‍💼', bgColor: 'bg-purple-50', textColor: 'text-purple-600' },
    // { label: 'Permissions', value: 6, icon: '🔐', bgColor: 'bg-pink-50', textColor: 'text-pink-600' }
  ];
  

}