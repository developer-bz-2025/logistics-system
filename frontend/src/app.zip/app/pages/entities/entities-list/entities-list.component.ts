import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EntityService } from 'src/app/core/services/entity.service';
import { Entity } from 'src/app/core/models/Entity';

@Component({
  selector: 'app-entities-list',
  templateUrl: './entities-list.component.html',
  styleUrls: ['./entities-list.component.scss']
})
export class EntitiesListComponent {

  entities: Entity[];
  displayedColumns: string[] = ['name', 'entities', 'total_emps','details'];
  dataSource: any;
  loading = true;

  constructor(private router : Router,
    private entityService: EntityService
  ) {
  }

  ngOnInit(): void {
    this.getentities();
  }
  navigateTo(path: string) {
    this.router.navigateByUrl(path);
  }

  getentities(){
    this.loading = true;
    this.entityService.getEntities().subscribe({
      next: (res) => {console.log(res)
        this.loading = false;
        this.entities = res as Entity[];
      },
      error: (err) => {
        this.loading = false;
        console.error('Failed to create country:', err)
      }
    });
  }

  entityDetails(id:number){
    this.router.navigate(["entities/entity-details",id])
  }
}
