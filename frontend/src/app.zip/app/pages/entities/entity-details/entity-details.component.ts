import { Component, Input } from '@angular/core';
import { EntityService } from 'src/app/core/services/entity.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-entity-details',
  templateUrl: './entity-details.component.html',
  styleUrls: ['./entity-details.component.scss']
})
export class EntityDetailsComponent {
  entityDetails: any=[];
  loading = true;
  entityId:number;
  unitSearch = '';
  @Input() units: any[] = [];


  
  constructor(private router : Router,
    private activatedRoute:ActivatedRoute,
    private entityService: EntityService
  ) {
    this.entityId = Number(this.activatedRoute.snapshot.paramMap.get('id'));  
  }

  
  addUnit() {
    // Implement unit creation logic or routing here
    console.log('Add unit clicked');
  }
  ngOnInit(): void {
    this.getentity();
  }
  navigateTo(path: string,id:number) {
    // this.router.navigateByUrl(path,id);
    this.router.navigate([path,id])
  }

  unitIconMap: { [key: string]: { icon: string; colorClass: string } } = {
    IT: { icon: 'computer', colorClass: 'bg-blue-100 text-blue-700' },
    HR: { icon: 'people', colorClass: 'bg-pink-100 text-pink-700' },
    Finance: { icon: 'account_balance', colorClass: 'bg-green-100 text-green-700' },
    Communications: { icon: 'campaign', colorClass: 'bg-orange-100 text-orange-700' },
    Logistic: { icon: 'local_shipping', colorClass: 'bg-lime-100 text-lime-700' },
    Research: { icon: 'science', colorClass: 'bg-purple-100 text-purple-700' },
    'Research & Development': { icon: 'science', colorClass: 'bg-purple-100 text-purple-700' },
  };
  
  getUnitIcon(unitName: string): string {
    return this.unitIconMap[unitName]?.icon || 'business';
  }
  
  getUnitColor(unitName: string): string {
    return this.unitIconMap[unitName]?.colorClass || 'bg-gray-200 text-gray-600';
  }

  getentity(){
    this.loading = true;
    this.entityService.entityDetails(this.entityId).subscribe({
      next: (res) => {console.log(res)
        this.loading = false;
        this.entityDetails = res;
      },
      error: (err) => {
        this.loading = false;
        console.error('Failed to create country:', err)
      }
    });
  }

  get filteredUnits() {
    if (!this.entityDetails || !this.entityDetails.units) {
      return [];
    }
  
    return this.entityDetails.units.filter((unit: any) =>
      unit.unit_name?.toLowerCase().includes(this.unitSearch?.toLowerCase() || '')
    );
  }
  

}
