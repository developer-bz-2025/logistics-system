import { Component } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AuthService } from 'src/app/core/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
})
export class AppSideLoginComponent {

  loginForm: FormGroup;
  loading = false;
  errorMessage = '';


  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router
  ) {

  }

  ngOnInit() {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }


  onSubmit() {
    if (this.loginForm.invalid) return;

    this.loading = true;
    this.errorMessage = '';

    this.auth.login(this.loginForm.value).subscribe({
      next: (res) => {
        console.log(res)
        this.auth.saveToken(res.access_token);
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        console.log(err)

        this.loading = false;

        const message = err.error?.error || '';

        if (message.includes('Email not found')) {
          this.errorMessage = 'This email is not registered.';
        } else if (message.includes('Incorrect password')) {
          this.errorMessage = 'Incorrect password. Please try again.';
        } else if (err.status === 422) {
          this.errorMessage = 'Email or password is required.';
        } else {
          this.errorMessage = 'Login failed. Please try again.';
        }
      },
      complete: () => {
        this.loading = false;
      }
    });
  }


}
