import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UnitService } from 'src/app/core/services/unit.service';

@Component({
  selector: 'app-units-list',
  templateUrl: './units-list.component.html',
  styleUrls: ['./units-list.component.scss']
})
export class UnitsListComponent {

  displayedColumns: string[] = ['name', 'entities', 'docs'];
  units:any;
  loading = true;

  constructor(private router : Router,
    private unitService: UnitService
  ) {
  }

  ngOnInit(): void {
    this.getUnits();
  }

  getUnits(){ 
    this.loading = true;
      this.unitService.getUnits().subscribe({
        next: (res) => {console.log(res)
          this.units = res;
          this.loading = false;
        },
        error: (err) => {
          this.loading = false;
          console.error('Failed to create country:', err)
        }
      });
    }

}
