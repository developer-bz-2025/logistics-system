import {
  Component,
  Output,
  EventEmitter,
  Input,
  ViewEncapsulation,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UserService } from 'src/app/core/services/user.service';
import { JwtService } from 'src/app/core/services/jwt.service';

// import jwt_decode from 'jwt-decode';
// import {jwtDecode} from 'jwt-decode';



@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  encapsulation: ViewEncapsulation.None,
})
export class HeaderComponent {
  @Input() showToggle = true;
  @Input() toggleChecked = false;
  @Output() toggleMobileNav = new EventEmitter<void>();
  @Output() toggleMobileFilterNav = new EventEmitter<void>();
  @Output() toggleCollapsed = new EventEmitter<void>();

  showFiller = false;
  user: any = null;



  constructor(public dialog: MatDialog, private userService: UserService, private jwtService: JwtService,
  ) { }

  ngOnInit(): void {
    console.log(this.jwtService.decodeToken())
    const userId = this.jwtService.getUserId();
    console.log(userId)
    if (userId) {
      this.userService.getUser(userId).subscribe({
        next: (data) => {
          console.log(data)
          this.user = data;
        },
        error: (err) => {
          console.error('Failed to fetch user data', err);
        }
      });
    }
  }

  roleGradientMap: { [key: string]: string } = {
    super_admin: 'from-[#F2709C] to-[#FF9400]',        // Gray
    country_dir: 'from-[#72C6EF] to-[#004E8F]',    // Cyan to Teal bg-gradient-to-br from-[#72C6EF] to-[#004E8F]
    head_of_entity: 'from-[#00416A] to-[#E4E5E6]',      // Orange bg-gradient-to-br from-[#00416A] to-[#E4E5E6]
    unit_admin: 'from-[#215F00] to-[#E4E4D9]',          // Blue bg-gradient-to-br from-[#215F00] to-[#E4E4D9]
    standard: 'from-[#FCE38A] to-[#F38181]',            // Yellow to Red
    c_level: 'from-[#F2709C] to-[#FF9400]',             // Purple gradient bg-gradient-to-br from-[#F2709C] to-[#FF9472]
    default: 'from-[#D3CCE3] to-[#E9E4F0]'              // Light fallback
  };
  
  getGradientClass(role: string): string {
    const gradient = this.roleGradientMap[role] || this.roleGradientMap['default'];
    return `bg-gradient-to-br ${gradient}`;
  }
}
