export const environment = {
    production: true,
    apiBaseUrl: 'https://bzassets/api'
  };